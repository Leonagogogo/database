package librarySystem.model;

public class Calculate {
	
	private String CalValue1;
	private String CalValue2;
	public Calculate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Calculate(String calValue1, String calValue2) {
		super();
		CalValue1 = calValue1;
		CalValue2 = calValue2;
	}
	public String getCalValue1() {
		return CalValue1;
	}
	public void setCalValue1(String calValue1) {
		CalValue1 = calValue1;
	}
	public String getCalValue2() {
		return CalValue2;
	}
	public void setCalValue2(String calValue2) {
		CalValue2 = calValue2;
	}
	
	

}
