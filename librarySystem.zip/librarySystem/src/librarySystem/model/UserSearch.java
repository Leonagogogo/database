package librarySystem.model;

public class UserSearch {
	
	private String fieldTxt;
	private String borrowerID;
	public String getFieldTxt() {
		return fieldTxt;
	}
	public void setFieldTxt(String fieldTxt) {
		this.fieldTxt = fieldTxt;
	}
	public String getBorrowerID() {
		return borrowerID;
	}
	public void setBorrowerID(String borrowerID) {
		this.borrowerID = borrowerID;
	}
	public UserSearch(String fieldTxt, String borrowerID) {
		super();
		this.fieldTxt = fieldTxt;
		this.borrowerID = borrowerID;
	}
	public UserSearch() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}
