package librarySystem.model;

public class UserUpdate {
	
	private String ID;
	private String Email;
	private String Address;
	private String Phone;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	public UserUpdate(String iD, String email, String address, String phone) {
		super();
		ID = iD;
		Email = email;
		Address = address;
		Phone = phone;
	}
	public UserUpdate() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
