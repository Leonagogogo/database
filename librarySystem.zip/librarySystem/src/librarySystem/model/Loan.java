package librarySystem.model;

import java.util.Date;


public class Loan {
	
	private int LoanId;
	private String ISBN;
	private String CardId;
	private String DateOut;
	private String DateIn;
	private String DueDay;
	private float fine;
	private int PayStatus;
	
	private String fieldTxt;
	
	
	public String getFieldTxt() {
		return fieldTxt;
	}
	public void setFieldTxt(String fieldTxt) {
		this.fieldTxt = fieldTxt;
	}
	public float getFine() {
		return fine;
	}
	public void setFine(float fine) {
		this.fine = fine;
	}
	public int getPayStatus() {
		return PayStatus;
	}
	public void setPayStatus(int payStatus) {
		PayStatus = payStatus;
	}
	public Loan(String iSBN, String cardId, String dayout, String dateIn, String dueday2) {
		super();
		ISBN = iSBN;
		CardId = cardId;
		DateOut = dayout;
		DateIn = dateIn;
		DueDay = dueday2;
	}
	public Loan() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getLoanId() {
		return LoanId;
	}
	public void setLoanId(int loanId) {
		LoanId = loanId;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public String getCardId() {
		return CardId;
	}
	public void setCardId(String cardId) {
		CardId = cardId;
	}
	public String getDateOut() {
		return DateOut;
	}
	public void setDateOut(String dateOut) {
		DateOut = dateOut;
	}
	public String getDateIn() {
		return DateIn;
	}
	public void setDateIn(String dateIn) {
		DateIn = dateIn;
	}
	public String getDueDay() {
		return DueDay;
	}
	public void setDueDay(String dueDay) {
		DueDay = dueDay;
	}
	
}
