package librarySystem.model;

public class Book {
	
	private int bookId;
	private String ISBN10;
	private String Title;
	private String Author;
	private String Publisher;
	private String Status;
	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Book(int bookId, String iSBN10, String title, String author, String publisher, String status) {
		super();
		this.bookId = bookId;
		ISBN10 = iSBN10;
		Title = title;
		Author = author;
		Publisher = publisher;
		Status = status;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public Book(String iSBN10, String title, String author,String publisher) {
		super();
		ISBN10 = iSBN10;
		Title = title;
		Author = author;
		Publisher = publisher;

	}

	
	public String getPublisher() {
		return Publisher;
	}
	public void setPublisher(String publisher) {
		Publisher = publisher;
	}

	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getISBN10() {
		return ISBN10;
	}
	public void setISBN10(String iSBN10) {
		ISBN10 = iSBN10;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getAuthor() {
		return Author;
	}
	public void setAuthor(String author) {
		Author = author;
	}
	
	

}
