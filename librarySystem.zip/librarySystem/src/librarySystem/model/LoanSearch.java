package librarySystem.model;

public class LoanSearch {

}
