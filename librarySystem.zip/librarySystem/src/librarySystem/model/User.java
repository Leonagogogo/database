package librarySystem.model;

public class User {
	

	private int id;
	private String username;
	private String userpassword;
	private String stuID;
	
	
	public User(String stuID) {
		super();
		this.stuID = stuID;
	}
	public String getStuID() {
		return stuID;
	}
	public void setStuID(String stuID) {
		this.stuID = stuID;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String username, String userpassword) {
		super();
		this.username = username;
		this.userpassword = userpassword;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpassword() {
		return userpassword;
	}
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}
	
	
	
	
}
