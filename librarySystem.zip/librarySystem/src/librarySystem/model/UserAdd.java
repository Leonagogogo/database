package librarySystem.model;

public class UserAdd {
	
	private String stuID;
	private String stuSSN;
	private String stuFname;
	private String stuLname;
	private String stuEmail;
	private String stuAddress;
	public String getStuID() {
		return stuID;
	}
	public void setStuID(String stuID) {
		this.stuID = stuID;
	}
	public String getStuSSN() {
		return stuSSN;
	}
	public void setStuSSN(String stuSSN) {
		this.stuSSN = stuSSN;
	}
	public String getStuFname() {
		return stuFname;
	}
	public void setStuFname(String stuFname) {
		this.stuFname = stuFname;
	}
	public String getStuLname() {
		return stuLname;
	}
	public void setStuLname(String stuLname) {
		this.stuLname = stuLname;
	}
	public String getStuEmail() {
		return stuEmail;
	}
	public void setStuEmail(String stuEmail) {
		this.stuEmail = stuEmail;
	}
	public String getStuAddress() {
		return stuAddress;
	}
	public void setStuAddress(String stuAddress) {
		this.stuAddress = stuAddress;
	}
	public UserAdd(String stuSSN, String stuFname, String stuLname, String stuEmail, String stuAddress) {
		super();
		this.stuSSN = stuSSN;
		this.stuFname = stuFname;
		this.stuLname = stuLname;
		this.stuEmail = stuEmail;
		this.stuAddress = stuAddress;
	}
	public UserAdd() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}
