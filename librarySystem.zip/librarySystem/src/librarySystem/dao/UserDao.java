package librarySystem.dao;

import java.sql.Connection;
import java.sql.ResultSet;

import java.sql.PreparedStatement;

import librarySystem.model.Book;
import librarySystem.model.BookSearch;
import librarySystem.model.User;
import librarySystem.model.UserAdd;
import librarySystem.model.UserSearch;
import librarySystem.model.UserUpdate;
import librarySystem.util.StringUtil;

public class UserDao {
	
	public User login(Connection con, User user)throws Exception{
		User resultUser = null;
		String sql = "select *from manager_info where username = ? and userpassword = ?";
		PreparedStatement pstmt=con.prepareStatement(sql);

		pstmt.setString(1, user.getUsername());
		pstmt.setString(2, user.getUserpassword());
		
		ResultSet rs=pstmt.executeQuery();
		
		if(rs.next()){
			resultUser=new User();
			resultUser.setUsername(rs.getString("username"));
			resultUser.setUserpassword(rs.getString("userpassword"));
		}
		
		return resultUser;
	}
	
	public ResultSet Userlist(Connection con, UserSearch userSearch)throws Exception{
		StringBuffer sb = new StringBuffer("select * from borrower_info");
		
		if(StringUtil.isNotEmpty(userSearch.getFieldTxt())){
			sb.append(" where borrower_id like '%"+userSearch.getFieldTxt()+"%' "
					+ "or ssn like '%"+userSearch.getFieldTxt()+"%' or first_name like '%"+userSearch.getFieldTxt()+"%' "
							+ "or last_name like '%"+userSearch.getFieldTxt()+"%'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString());
		return pstmt.executeQuery();

	}
	
	public ResultSet UsersearchList(Connection con, UserSearch userSearch)throws Exception{
		
		String sql = "select * from borrower_info where borrower_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, userSearch.getBorrowerID());
		return pstmt.executeQuery();

	}
	
	public int addUser(Connection con, UserAdd userAdd)throws Exception{
		String sql = "insert into borrower_info (borrower_id,ssn,first_name, last_name, email, address,city, state,phone) VALUES (null,?,?,?,?,?,null,null,null)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, userAdd.getStuSSN());
		pstmt.setString(2, userAdd.getStuFname());
		pstmt.setString(3, userAdd.getStuLname());
		pstmt.setString(4, userAdd.getStuEmail());
		pstmt.setString(5, userAdd.getStuAddress());
		return pstmt.executeUpdate();
	}
	
	public int updateUser(Connection con, UserUpdate userUpdate)throws Exception{
		String sql = "update borrower_info set email = ?, address = ?, phone = ? where borrower_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, userUpdate.getEmail());
		pstmt.setString(2, userUpdate.getAddress());
		pstmt.setString(3, userUpdate.getPhone());
		pstmt.setString(4, userUpdate.getID());
		return pstmt.executeUpdate();
	}
	
	public int deleteUser(Connection con, UserUpdate userUpdate)throws Exception{
		String sql = "delete from borrower_info where borrower_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, userUpdate.getID());
		
		return pstmt.executeUpdate();
	}
	
	public ResultSet UserCheck(Connection con, UserAdd userAdd)throws Exception{
		
		String sql = "select ssn from borrower_info";
		PreparedStatement pstmt = con.prepareStatement(sql);
		return pstmt.executeQuery();

	}
	
	public ResultSet AddUserCheck(Connection con, UserAdd userAdd)throws Exception{
		
		String sql = "select borrower_id from borrower_info where ssn = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, userAdd.getStuSSN());
		return pstmt.executeQuery();

	}
	
	

}
