package librarySystem.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import librarySystem.model.Book;
import librarySystem.model.BookSearch;
import librarySystem.model.Calculate;
import librarySystem.model.Loan;
import librarySystem.model.User;
import librarySystem.util.StringUtil;

public class BookDao {

	public int add(Connection con, Book book)throws Exception{
		String sql = "insert into books (ISBN10,ISBN13,TITLE, AUTHOR, COVER, PUBLISHER,PAGES, BOOKID,STATUS) VALUES (?,null,?,?,null,?,null,null,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, book.getISBN10());
		pstmt.setString(2, book.getTitle());
		pstmt.setString(3, book.getAuthor());
		pstmt.setString(4, book.getPublisher());
		pstmt.setString(5, book.getStatus());

		return pstmt.executeUpdate();
	}
	
	public int addLoan(Connection con, Loan loanbook)throws Exception{
		String sql = "insert into BOOK_LOANS (loan_id,ISBN,Card_id, Date_out, Due_date, Date_in) VALUES (null,?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loanbook.getISBN());
		pstmt.setString(2, loanbook.getCardId());
		pstmt.setString(3, loanbook.getDateOut());
		pstmt.setString(4, loanbook.getDueDay());
		pstmt.setString(5, loanbook.getDateIn());

		return pstmt.executeUpdate();		
	}
	
	
	public ResultSet list(Connection con, BookSearch bookSearch)throws Exception{
		StringBuffer sb = new StringBuffer("select * from books");
		
		if(StringUtil.isNotEmpty(bookSearch.getFieldTxt())){
			sb.append(" where bookid like '%"+bookSearch.getFieldTxt()+"%' "
					+ "or isbn10 like '%"+bookSearch.getFieldTxt()+"%' or title like '%"+bookSearch.getFieldTxt()+"%' "
							+ "or author like '%"+bookSearch.getFieldTxt()+"%'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString());
		return pstmt.executeQuery();

	}
	
	public ResultSet searchList(Connection con, Book book)throws Exception{
			
		String sql = "select * from books where bookid = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, book.getBookId());
		return pstmt.executeQuery();

	}
	
	public int borrowUpdatelist(Connection con, Loan loanbook)throws Exception{
		String sql = "update books SET status = 'check out' where isbn10 = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loanbook.getISBN());
		return pstmt.executeUpdate();
	}
	
	public int returnUpdateBookStatus(Connection con, Book book)throws Exception{
		String sql = "update books SET status = 'available' where isbn10 = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1,book.getISBN10());
		
		return pstmt.executeUpdate();		
	}
	
	public int bookUpdatelist(Connection con, Book book)throws Exception{
		String sql = "update books SET Title = ?, Author = ?, Publisher = ? where BookId = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, book.getTitle());
		pstmt.setString(2, book.getAuthor());
		pstmt.setString(3, book.getPublisher());
		pstmt.setInt(4, book.getBookId());
		return pstmt.executeUpdate();
	}
	
	public int deleteBook(Connection con, Book book)throws Exception{
		String sql = "delete from books where BookID = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, book.getBookId());
		
		return pstmt.executeUpdate();
	}
	
	public ResultSet countBook(Connection con, User user)throws Exception{
		String sql = "select count(status) from book_loans, books where card_id = ? and book_loans.isbn = books.isbn10 and status = 'check out'";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, user.getStuID());
		return pstmt.executeQuery();
	}
	
	public ResultSet countFine(Connection con, Loan loanSearch)throws Exception{
		String sql = "select sum(fine) from book_loans where card_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loanSearch.getCardId());
		return pstmt.executeQuery();
	}
	
	public int returnBook(Connection con, Loan loanbook)throws Exception{
		
		String sql = "update book_loans set date_in = ? where loan_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loanbook.getDateIn());
		pstmt.setInt(2, loanbook.getLoanId());
		
		return pstmt.executeUpdate();
	}
	
	public int totalPayUpdate(Connection con, Loan loanSearch)throws Exception{
		
		String sql = "update book_loans set fine = 0 , pay_status = 0 where loan_id = ? ";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, loanSearch.getLoanId());
		
		return pstmt.executeUpdate();
	}
	
	public int deleteReturnBook(Connection con, Loan loanbook)throws Exception{
		String sql = "delete from book_loans where card_id = ? and ISBN = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loanbook.getCardId());
		pstmt.setString(2, loanbook.getISBN());
		
		return pstmt.executeUpdate();
	}
	
	public ResultSet duedaylist(Connection con, Loan loanbook)throws Exception{
		String sql = "select due_date, pay_status from book_loans where card_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loanbook.getCardId());
		
		return pstmt.executeQuery();
	}
	
	public ResultSet fineUpdateList(Connection con, Loan loanbook)throws Exception{
		String sql = "select loan_id, due_date, date_in,pay_status from book_loans";
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		return pstmt.executeQuery();
	}
	
	public ResultSet fineUpdateListReferID(Connection con, Loan loansearch)throws Exception{
		String sql = "select loan_id, due_date, date_in,pay_status from book_loans where card_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loansearch.getCardId());
		return pstmt.executeQuery();
	}
	
	public ResultSet timeDiff(Connection con, Calculate diff)throws Exception{
		String sql = "select DATEDIFF(?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, diff.getCalValue1());
		pstmt.setString(2, diff.getCalValue2());		
		
		return pstmt.executeQuery();
	}
	
	public ResultSet fineSearch(Connection con, Loan loansearch)throws Exception{
		String sql = "select * from book_loans where loan_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, loansearch.getLoanId());	
		return pstmt.executeQuery();
	}
	
	public ResultSet fineSearchID(Connection con, Loan loansearch)throws Exception{
		String sql = "select * from book_loans,books where book_loans.isbn = books.isbn10 and card_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loansearch.getCardId());	
		return pstmt.executeQuery();
	}
	
	public ResultSet fineSearchloanID(Connection con, Loan loansearch)throws Exception{
		String sql = "select * from book_loans,books where book_loans.isbn = books.isbn10 and loan_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, loansearch.getLoanId());	
		return pstmt.executeQuery();
	}
	
	public ResultSet fineSearchtable(Connection con, Loan loansearch)throws Exception{
		String sql = "select * from book_loans,books where book_loans.isbn = books.isbn10";
		PreparedStatement pstmt = con.prepareStatement(sql);
		return pstmt.executeQuery();
	}
	
	public int updateBookFine(Connection con, Loan loansearch)throws Exception{
		
		String sql = "update book_loans set fine = ?, pay_status = ? where loan_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setFloat(1, loansearch.getFine());
		pstmt.setInt(2, loansearch.getPayStatus());
		pstmt.setInt(3, loansearch.getLoanId());
		
		return pstmt.executeUpdate();
	}
	
	public ResultSet paySearchlist(Connection con, Loan loansearch)throws Exception{
		String sql = "select Title, Fine from books, book_loans where card_id = ? and isbn10 = isbn";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loansearch.getCardId());
		return pstmt.executeQuery();
	}
	
	public int payMoneylist(Connection con, Loan loansearch)throws Exception{
		String sql = "update book_loans set fine = ? where card_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setFloat(1, loansearch.getFine());
		pstmt.setString(2, loansearch.getCardId());
		
		return pstmt.executeUpdate();
	}
	
	public ResultSet fineGroup1(Connection con, Loan loansearch)throws Exception{
		String sql = "select count(*) from book_loans,books where card_id = ? and book_loans.ISBN = books.ISBN10 and status = 'check out'";
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loansearch.getCardId());
		return pstmt.executeQuery();
	}
	
	public ResultSet fineGroup3(Connection con, Loan loansearch)throws Exception{
		StringBuffer sb = new StringBuffer("select * from book_loans,books");
		
		if(StringUtil.isNotEmpty(loansearch.getFieldTxt())){
			sb.append(" where bookid like '%"+loansearch.getFieldTxt()+"%'"
					+ "or Card_id like '%"+loansearch.getFieldTxt()+"%'"
					+"and book_loans.ISBN = books.ISBN10 and status = 'check out'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString());

		return pstmt.executeQuery();
	}
	
	public ResultSet fineGroup2(Connection con, Loan loansearch)throws Exception{
		String sql = "select sum(fine) from book_loans,books where card_id = ? and book_loans.ISBN = books.ISBN10 and pay_status = 1";
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loansearch.getCardId());
		return pstmt.executeQuery();
	}
	
	public ResultSet bookMoreInfo(Connection con, Loan loansearch)throws Exception{
		String sql = "select * from book_loans, books where book_loans.ISBN = books.ISBN10 and (status = 'check out' or pay_status = 1) and card_id = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, loansearch.getCardId());
		return pstmt.executeQuery();
	
	}

}
