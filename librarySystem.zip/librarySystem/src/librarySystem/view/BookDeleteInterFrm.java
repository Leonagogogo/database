package librarySystem.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;

import librarySystem.dao.BookDao;
import librarySystem.model.Book;
import librarySystem.util.DbUtil;
import librarySystem.util.StringUtil;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;

public class BookDeleteInterFrm extends JInternalFrame {
	private JTextField deleteBookTxt;
	private Book bookDelete;
	private DbUtil dbUtil = new DbUtil();
	private BookDao bookDao = new BookDao();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookDeleteInterFrm frame = new BookDeleteInterFrm();
					frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookDeleteInterFrm() {
		setClosable(true);
		setBounds(50, 100, 450, 240);
		
		JLabel lblPleaseInputBook = new JLabel("Please input Book ID...");
		lblPleaseInputBook.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		deleteBookTxt = new JTextField();
		deleteBookTxt.setColumns(10);
		
		JButton btnNewButton = new JButton("GO");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookDeleteActionPerformed(e);
			}
		});
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(41)
					.addComponent(lblPleaseInputBook)
					.addContainerGap(324, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
					.addContainerGap(65, Short.MAX_VALUE)
					.addComponent(deleteBookTxt, GroupLayout.PREFERRED_SIZE, 229, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnNewButton)
					.addGap(39))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(59)
					.addComponent(lblPleaseInputBook)
					.addGap(31)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(deleteBookTxt, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addContainerGap(120, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);

	}

	private void bookDeleteActionPerformed(ActionEvent evt) {
		String bookID = deleteBookTxt.getText();
		int BookId = Integer.parseInt(bookID);
		if(StringUtil.isEmpty(bookID)) {
			JOptionPane.showMessageDialog(null, "Please input Book ID");	
			return;
		}
		
		Connection con = null;
		bookDelete.setBookId(BookId);
		Book book = new Book();
		
		try{
			con = dbUtil.getCon();
			int deleteinfo = bookDao.deleteBook(con, book);
			if(deleteinfo == 1) {
				JOptionPane.showMessageDialog(null, "Success to delete");	
				return;
			}else {
				JOptionPane.showMessageDialog(null, "Failure to delete");	
				return;
			}	
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Failure to connect to database when deleting books!");
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		
	}		
		
}
