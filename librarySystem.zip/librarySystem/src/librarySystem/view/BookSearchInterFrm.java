package librarySystem.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import librarySystem.dao.BookDao;
import librarySystem.model.Book;
import librarySystem.model.BookSearch;
import librarySystem.model.Loan;
import librarySystem.model.User;
import librarySystem.model.UserSave;
import librarySystem.util.DbUtil;
import librarySystem.util.StringUtil;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;

public class BookSearchInterFrm extends JInternalFrame {
	
	private DbUtil dbUtil = new DbUtil();
	private BookDao bookDao = new BookDao();
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	Calendar cal = Calendar.getInstance();	
	int count = 0;

	private JTextField searchTxt;
	private JTable bookTable;
	private JTextField isbnTxt;
	private JTextField publisherTxt;
	private JTextField statusTxt;
	private JTextField bookIDTxt;
	private JTextField stuIdTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookSearchInterFrm frame = new BookSearchInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookSearchInterFrm() {
		setClosable(true);
		setTitle("Search");
		setBounds(5, 5, 561, 466);
		
		searchTxt = new JTextField();
		searchTxt.setColumns(10);
		
		JButton btnNewButton = new JButton("Go");
		btnNewButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 searchBookActionPerformed(e);
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Desc", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(76)
							.addComponent(searchTxt, GroupLayout.PREFERRED_SIZE, 282, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnNewButton))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(21)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(panel, GroupLayout.PREFERRED_SIZE, 496, GroupLayout.PREFERRED_SIZE)
								.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 494, GroupLayout.PREFERRED_SIZE))))
					.addContainerGap(20, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(15)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(searchTxt, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		JLabel lblIsbn = new JLabel("ISBN");
		
		isbnTxt = new JTextField();
		isbnTxt.setColumns(10);
		
		JLabel lblPublisher = new JLabel("Publisher");
		
		publisherTxt = new JTextField();
		publisherTxt.setColumns(10);
		
		JLabel lblStatus = new JLabel("Status");
		
		statusTxt = new JTextField();
		statusTxt.setColumns(10);
		
		JButton btnBorrower = new JButton("CHECK OUT");
		btnBorrower.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookBorrowerActionPerformed(e);
				
			}
		});
		
		JLabel lblBookid = new JLabel("BookId");
		
		bookIDTxt = new JTextField();
		bookIDTxt.setColumns(10);
		
		JLabel lblId = new JLabel("ID");
		lblId.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		stuIdTxt = new JTextField();
		stuIdTxt.setColumns(10);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(20)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addComponent(btnBorrower)
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblPublisher)
								.addComponent(lblIsbn)
								.addComponent(lblBookid))
							.addGap(19)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(isbnTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(lblId)
									.addGap(37)
									.addComponent(stuIdTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(bookIDTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addGap(56)
									.addComponent(lblStatus)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(statusTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
								.addComponent(publisherTxt))))
					.addContainerGap(20, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblStatus)
						.addComponent(statusTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblBookid)
						.addComponent(bookIDTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(publisherTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblPublisher))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblIsbn)
						.addComponent(isbnTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblId)
						.addComponent(stuIdTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addComponent(btnBorrower)
					.addContainerGap(11, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		
		bookTable = new JTable();
		bookTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				mousePressTableDescActionPerformed(e);
			}
		});
	
		bookTable.setModel((TableModel) new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"BookId", "Title", "Author"
				}
			) {
				boolean[] columnEditables = new boolean[] {
					false, false, false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
			});
		bookTable.getColumnModel().getColumn(1).setPreferredWidth(135);
		bookTable.getColumnModel().getColumn(2).setPreferredWidth(115);
		scrollPane.setViewportView(bookTable);
		getContentPane().setLayout(groupLayout);
		
		this.fillTable(new BookSearch());
	}
	
	private void bookBorrowerActionPerformed(ActionEvent evt) {
		int bookid = Integer.parseInt(bookIDTxt.getText());
		Book book = new Book();
		book.setBookId(bookid);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			ResultSet result = bookDao.searchList(con, book);
			while (result.next()) {
				String resultValue = result.getString("status");
				if( resultValue.equals("available")){			
					String stuID = stuIdTxt.getText();
					if(StringUtil.isEmpty(stuID)) {
						JOptionPane.showMessageDialog(null, "Please input the ID.");
						return;
					}else {
						bookBorrowerSureActionPerformed(evt);
						}
				}else {
					JOptionPane.showMessageDialog(null, "This book is checking out!");
					return;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
	}

	private void mousePressTableDescActionPerformed(MouseEvent evt) {
		int row = bookTable.getSelectedRow();
		int Value = Integer.parseInt((String)bookTable.getValueAt(row, 0));
		Book book = new Book();
		book.setBookId(Value);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = bookDao.searchList(con, book);
			
			while (rs.next()) {
				bookIDTxt.setText((String)bookTable.getValueAt(row, 0));
				isbnTxt.setText(rs.getString("ISBN10"));
				statusTxt.setText(rs.getString("status"));
				publisherTxt.setText(rs.getString("publisher"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
		
	}

	private void fillTable(BookSearch bookSearch) {
		DefaultTableModel dtm = (DefaultTableModel) bookTable.getModel();
		dtm.setRowCount(0);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = bookDao.list(con, bookSearch);
			while (rs.next()) {
				Vector v = new Vector();
				v.add(rs.getString("bookid"));
				v.add(rs.getString("title"));
				v.add(rs.getString("author"));
				dtm.addRow(v);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void searchBookActionPerformed(ActionEvent e) {
		String s_bookTypeName = this.searchTxt.getText();
		BookSearch bookSearch = new BookSearch();
		bookSearch.setFieldTxt(s_bookTypeName);
		this.fillTable(bookSearch);
		
	}

	private void bookBorrowerSureActionPerformed(ActionEvent evt) {	
		Calendar cal = Calendar.getInstance();	
		String bookISBN= isbnTxt.getText();
		String stuID = stuIdTxt.getText();
		Date Dayout = cal.getTime();
		String dayout = sdf.format(Dayout);
		cal.add(Calendar.DATE, 14);
		Date Dueday = (Date) cal.getTime();
		String dueday = sdf.format(Dueday);
		
		User user = new User();
		user.setStuID(stuID);
		
		if(StringUtil.isEmpty(stuID)) {
			JOptionPane.showMessageDialog(null, "Please input the student ID.");
			return;		
		}else {
				Loan loanbook = new Loan(bookISBN,stuID,dayout,null,dueday); 
				Connection con = null;
				
				try {
					con = dbUtil.getCon();		
					ResultSet rs = bookDao.countBook(con, user);
					while(rs.next()){
						count = Integer.parseInt(rs.getString(1));
						if(count == 3){
							JOptionPane.showMessageDialog(null, "You have reached the maxmum borrowed books.Cann't borrow more books.");
							return;
						}else {
							int loanstatus = bookDao.addLoan(con, loanbook);	
							if(loanstatus == 1) {
								int borrowstatus = bookDao.borrowUpdatelist(con, loanbook);
								if(borrowstatus == 1) {
									JOptionPane.showMessageDialog(null, "Succeed to borrow the book.");
									return;
								}	
							}else {
								JOptionPane.showMessageDialog(null, "Failure to borrow the book.");
								return;							
							}							
						}											
					}
	
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						dbUtil.closeCon(con);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
}
