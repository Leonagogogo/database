package librarySystem.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;

import librarySystem.dao.BookDao;
import librarySystem.model.Loan;
import librarySystem.util.DbUtil;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class BookPayInterFrm extends JInternalFrame {
	private JTextField idTxt;
	private JTextField book1TitleTxt;
	private JTextField book1FineTxt;
	
	private DbUtil dbUtil = new DbUtil();
	private BookDao bookDao = new BookDao();
	private Loan loanSearch = new Loan();
	private JTextField book2TitleTxt;
	private JTextField book2FineTxt;
	private JTextField book3TitleTxt;
	private JTextField book3FineTxt;
	private JTextField totalTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookPayInterFrm frame = new BookPayInterFrm();
					frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookPayInterFrm() {
		setClosable(true);
		setBounds(8, 8, 565, 459);
		
		idTxt = new JTextField();
		idTxt.setColumns(10);
		
		JButton btnGo = new JButton("GO");
		btnGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				paySearchActionPerformed(e);
			}
		});
		btnGo.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblBookTitle = new JLabel("Book_1 ");
		lblBookTitle.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		book1TitleTxt = new JTextField();
		book1TitleTxt.setColumns(10);
		
		book1FineTxt = new JTextField();
		book1FineTxt.setColumns(10);
		
		JLabel label_1 = new JLabel("Fine");
		label_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblId = new JLabel("ID");
		lblId.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel label = new JLabel("Book_1 ");
		label.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel label_2 = new JLabel("Fine");
		label_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		book2TitleTxt = new JTextField();
		book2TitleTxt.setColumns(10);
		
		book2FineTxt = new JTextField();
		book2FineTxt.setColumns(10);
		
		JLabel label_3 = new JLabel("Book_1 ");
		label_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel label_4 = new JLabel("Fine");
		label_4.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		book3TitleTxt = new JTextField();
		book3TitleTxt.setColumns(10);
		
		book3FineTxt = new JTextField();
		book3FineTxt.setColumns(10);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		totalTxt = new JTextField();
		totalTxt.setColumns(10);
		
		JButton button_2 = new JButton("PAY");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				payUpdateInterFrm(e);
			}
		});
		button_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap(34, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(lblId)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(label, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
								.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
								.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
								.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
								.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblBookTitle)
								.addComponent(lblTotal))
							.addGap(26)))
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(18)
							.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, 206, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(btnGo))
						.addComponent(book2TitleTxt, GroupLayout.PREFERRED_SIZE, 350, GroupLayout.PREFERRED_SIZE)
						.addComponent(book3TitleTxt, GroupLayout.PREFERRED_SIZE, 350, GroupLayout.PREFERRED_SIZE)
						.addComponent(book1FineTxt, GroupLayout.PREFERRED_SIZE, 106, GroupLayout.PREFERRED_SIZE)
						.addComponent(book2FineTxt, GroupLayout.PREFERRED_SIZE, 106, GroupLayout.PREFERRED_SIZE)
						.addComponent(book1TitleTxt, GroupLayout.PREFERRED_SIZE, 350, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(totalTxt, Alignment.LEADING, 0, 0, Short.MAX_VALUE)
								.addComponent(book3FineTxt, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE))
							.addGap(40)
							.addComponent(button_2, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(77, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(22)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblId)
						.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnGo))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(book1TitleTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblBookTitle))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(book1FineTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 18, GroupLayout.PREFERRED_SIZE))
					.addGap(30)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label, GroupLayout.PREFERRED_SIZE, 18, GroupLayout.PREFERRED_SIZE)
						.addComponent(book2TitleTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 18, GroupLayout.PREFERRED_SIZE)
						.addComponent(book2FineTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(33)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 18, GroupLayout.PREFERRED_SIZE)
						.addComponent(book3TitleTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 18, GroupLayout.PREFERRED_SIZE)
						.addComponent(book3FineTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(27)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTotal)
						.addComponent(totalTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(button_2))
					.addContainerGap(18, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);

	}

	private void payUpdateInterFrm(ActionEvent evt) {
		String ID = idTxt.getText();
		loanSearch.setCardId(ID);
		Connection con=null;
		try {
			con = dbUtil.getCon();
			int resultvalue = bookDao.totalPayUpdate(con, loanSearch);
			if(resultvalue == 1) {
				JOptionPane.showMessageDialog(null, "Succedd to pay!");
				return;			
			}else {
				JOptionPane.showMessageDialog(null, "Failure to pay!");
				return;	
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
	}		

	private void paySearchActionPerformed(ActionEvent evt) {	
		String txtTitle[];
		String txtFine[];
		int i = 0;
		int j = 0;
		String ID = idTxt.getText();		
		loanSearch.setCardId(ID);
		Connection con= null;
		txtTitle = new String[3];
		txtFine = new String[3];
		try {
			con = dbUtil.getCon();
			ResultSet rs = bookDao.paySearchlist(con, loanSearch);
			while(rs.next()) {
				txtTitle[i] = rs.getString("Title");
				txtFine[j] = rs.getString("fine");
				i = i+1;
				j = j+1;
			}
			book1TitleTxt.setText(txtTitle[0]);
			book1FineTxt.setText(txtFine[0]);
			book2TitleTxt.setText(txtTitle[1]);
			book2FineTxt.setText(txtFine[1]);
			book3TitleTxt.setText(txtTitle[2]);
			book3FineTxt.setText(txtFine[2]);	
			
			
			ResultSet rs1 = bookDao.countFine(con, loanSearch);
			while(rs1.next()) {
				float result = rs1.getFloat(1);
				totalTxt.setText(String.valueOf(result));
			}
				
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
	}
}
