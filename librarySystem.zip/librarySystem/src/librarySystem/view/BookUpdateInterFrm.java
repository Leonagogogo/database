package librarySystem.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;

import librarySystem.dao.BookDao;
import librarySystem.model.Book;
import librarySystem.model.UserUpdate;
import librarySystem.util.DbUtil;
import librarySystem.util.StringUtil;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;

public class BookUpdateInterFrm extends JInternalFrame {
	private JTextField bookidTxt;
	private JTextField titleTxt;
	private JTextField authorTxt;
	private JTextField publisherTxt;
	
	private DbUtil dbUtil = new DbUtil();
	private BookDao bookDao = new BookDao();
	
	private Book book = new Book();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookUpdateInterFrm frame = new BookUpdateInterFrm();
					frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookUpdateInterFrm() {
		setClosable(true);
		setBounds(65, 50, 450, 390);
		
		JLabel lblNewLabel = new JLabel("BookID");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblTitle = new JLabel("Title");
		lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblAuthor = new JLabel("Author");
		lblAuthor.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		bookidTxt = new JTextField();
		bookidTxt.setColumns(10);
		
		titleTxt = new JTextField();
		titleTxt.setColumns(10);
		
		authorTxt = new JTextField();
		authorTxt.setColumns(10);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateValueActionPerformed(e);
			}
		});
		btnUpdate.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookUpdateResetActionPerformed(e);
			}
		});
		btnReset.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblPublisher = new JLabel("Publisher");
		lblPublisher.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		publisherTxt = new JTextField();
		publisherTxt.setColumns(10);
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(56)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblPublisher)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(publisherTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(167))
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
							.addGroup(groupLayout.createSequentialGroup()
								.addComponent(lblAuthor)
								.addContainerGap())
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(lblTitle)
									.addContainerGap())
								.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
									.addGroup(groupLayout.createSequentialGroup()
										.addGap(68)
										.addComponent(btnUpdate)
										.addPreferredGap(ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
										.addComponent(btnReset)
										.addGap(18))
									.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
										.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 62, GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
											.addComponent(authorTxt, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
											.addComponent(titleTxt, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
											.addComponent(bookidTxt, GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE))
										.addGap(124)))))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(36)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(bookidTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(27)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTitle)
						.addComponent(titleTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(29)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAuthor)
						.addComponent(authorTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(33)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPublisher)
						.addComponent(publisherTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnUpdate)
						.addComponent(btnReset))
					.addGap(37))
		);
		getContentPane().setLayout(groupLayout);

	}

	private void updateValueActionPerformed(ActionEvent evt) {
		String author = authorTxt.getText();
		String title = titleTxt.getText();
		String publisher = publisherTxt.getText();
		String bookid = bookidTxt.getText();
		
		if(StringUtil.isEmpty(bookid)) {
			JOptionPane.showMessageDialog(null, "Please input Book ID");
			return;
		}
		if(StringUtil.isEmpty(title)) {
			JOptionPane.showMessageDialog(null, "Please input Book Title");
			return;
		}
		if(StringUtil.isEmpty(author)) {
			JOptionPane.showMessageDialog(null, "Please input Book Author");
			return;
		}
		if(StringUtil.isEmpty(publisher)) {
			JOptionPane.showMessageDialog(null, "Please input Book Publiser");
			return;
		}
				
		book.setBookId(Integer.parseInt(bookid));
		book.setAuthor(author);
		book.setTitle(title);
		book.setPublisher(publisher);
		
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int updatebook = bookDao.bookUpdatelist(con, book);
			if(updatebook == 1) {
				JOptionPane.showMessageDialog(null, "Succeed to update the book info");
				updateResetValue();
			}else {
				JOptionPane.showMessageDialog(null, "Failure to update the book info");
				updateResetValue();
			}
			
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Failure to connect to database when updating books!");
			updateResetValue();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		
	}

	private void bookUpdateResetActionPerformed(ActionEvent e) {
		
		this.updateResetValue();
	}
	
	private void updateResetValue() {
		this.bookidTxt.setText("");
		this.authorTxt.setText("");
		this.titleTxt.setText("");
		this.publisherTxt.setText("");
	}
}
