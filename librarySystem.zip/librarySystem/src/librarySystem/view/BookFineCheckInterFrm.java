package librarySystem.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import librarySystem.dao.BookDao;
import librarySystem.model.Calculate;
import librarySystem.model.Loan;
import librarySystem.model.UserSearch;
import librarySystem.util.DbUtil;

import javax.swing.JButton;
import java.awt.Font;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BookFineCheckInterFrm extends JInternalFrame {
	private JTable fineTable;
	
	private DbUtil dbUtil = new DbUtil();
	private BookDao bookDao = new BookDao();
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	Calendar cal = Calendar.getInstance();
	
	private Calculate calDiff = new Calculate();
	private JTextField idTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookFineCheckInterFrm frame = new BookFineCheckInterFrm();
					frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookFineCheckInterFrm() {
		setClosable(true);
		setBounds(10, 10, 558, 448);
		
		JLabel label = new JLabel("");
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookfineUpdateActionPerformed(e);
			}
		});
		btnUpdate.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		idTxt = new JTextField();
		idTxt.setColumns(10);
		
		JButton btnGo = new JButton("GO");
		btnGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IDSearchBorrowerStatusActionPerformed(e);
			}
		});
		btnGo.setFont(new Font("Times New Roman", Font.BOLD, 15));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(21)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 498, GroupLayout.PREFERRED_SIZE)
								.addComponent(label)))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(120)
							.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, 221, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(btnGo))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(206)
							.addComponent(btnUpdate)))
					.addContainerGap(15, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(17)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(label)
						.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
							.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
							.addComponent(btnGo)))
					.addPreferredGap(ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 273, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnUpdate)
					.addContainerGap())
		);
		
		fineTable = new JTable();
		
		fineTable.setModel((TableModel) new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"LoanId", "StuId", "DueDay","Fines","PayStatus","BookStatus"
				}
			) {
				boolean[] columnEditables = new boolean[] {
					false, false, false,false,false,false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
			});
		fineTable.getColumnModel().getColumn(1).setPreferredWidth(50);
		fineTable.getColumnModel().getColumn(2).setPreferredWidth(80);
		fineTable.getColumnModel().getColumn(3).setPreferredWidth(100);
		fineTable.getColumnModel().getColumn(4).setPreferredWidth(100);
		scrollPane.setViewportView(fineTable);
		getContentPane().setLayout(groupLayout);
		
		this.finefillTable(new Loan());

	}
	private void IDSearchBorrowerStatusActionPerformed(ActionEvent evt) {
		DefaultTableModel dtm = (DefaultTableModel) fineTable.getModel();
		dtm.setRowCount(0);
		
		String stuID = idTxt.getText();
		Loan loanSearch = new Loan();
		loanSearch.setCardId(stuID);
		Connection con = null;
		
		try {
			con = dbUtil.getCon();
			ResultSet rs = bookDao.fineSearchID(con, loanSearch);
			while (rs.next()) {	
				Vector v = new Vector();
				v.add(rs.getString("loan_id"));
				v.add(rs.getString("card_id"));
				v.add(rs.getString("due_date"));
				v.add(rs.getString("fine"));
				v.add(rs.getString("pay_status"));
				if(rs.getString("status").equals("available")) {
					v.add("returned");
				}else {
					v.add("not returned");
				}
				dtm.addRow(v);		
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
	}

	private void bookfineUpdateActionPerformed(ActionEvent evt) {
		bookfineUpdate();
		this.finefillTable(new Loan());
	}
	
	
	private void bookfineUpdate() {
		Date currentValue = cal.getTime();
		String CValue = sdf.format(currentValue);
		Connection con = null;
		Loan loanSearch = new Loan();
		try {
			con = dbUtil.getCon();
			ResultSet rs = bookDao.fineUpdateList(con, loanSearch);
			while (rs.next()) {
				String duedate = rs.getString("due_date");
				calDiff.setCalValue1(duedate);
				calDiff.setCalValue2(CValue);
				ResultSet rs1 = bookDao.timeDiff(con, calDiff);
				while(rs1.next()) {
					int diffcal = rs1.getInt(1);
					if(diffcal < 0) {
						String dayin = rs.getString("date_in");
						if(dayin == null) {
							int ID =Integer.parseInt(rs.getString("loan_id"));
							loanSearch.setLoanId(ID);	
							float Bookfines = (float) (Math.abs(diffcal) * 0.25);
							loanSearch.setFine(Bookfines);
							int Finestatus = 1;
							loanSearch.setPayStatus(Finestatus);
							
							int finestatus = bookDao.updateBookFine(con, loanSearch);
							if(finestatus != 1) {
								JOptionPane.showMessageDialog(null, "Failure to update!");
								return;								
							}							
						}
					}
				}
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
	}		

	private void finefillTable(Loan loanSearch) {
		DefaultTableModel dtm = (DefaultTableModel) fineTable.getModel();
		dtm.setRowCount(0);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = bookDao.fineSearchtable(con, loanSearch);
			while (rs.next()) {
				Vector v = new Vector();
				v.add(rs.getString("loan_id"));
				v.add(rs.getString("card_id"));
				v.add(rs.getString("due_date"));
				v.add(rs.getString("fine"));
				v.add(rs.getString("pay_status"));
				if(rs.getString("status").equals("available")) {
					v.add("returned");
				}else {
					v.add("not returned");
				}
				dtm.addRow(v);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
