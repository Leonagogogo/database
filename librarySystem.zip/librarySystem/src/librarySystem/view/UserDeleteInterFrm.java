package librarySystem.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;

import librarySystem.dao.UserDao;
import librarySystem.model.UserUpdate;
import librarySystem.util.DbUtil;
import librarySystem.util.StringUtil;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;

public class UserDeleteInterFrm extends JInternalFrame {
	private JTextField idTxt;
	
	private DbUtil dbUtil = new DbUtil();
	private UserDao userDao = new UserDao();
	private UserUpdate userUpdate = new UserUpdate();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserDeleteInterFrm frame = new UserDeleteInterFrm();
					frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserDeleteInterFrm() {
		setClosable(true);
		setTitle("Delete");
		setBounds(65, 100, 450, 242);
		
		JLabel lblPleaseInputSsn = new JLabel("Please input ID......");
		lblPleaseInputSsn.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		idTxt = new JTextField();
		idTxt.setColumns(10);
		
		JButton btnNewButton = new JButton("GO");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userDeleteActionPerformed(e);
			}
		});
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(74)
							.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, 205, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(btnNewButton))
						.addGroup(groupLayout.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblPleaseInputSsn, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(54, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(38)
					.addComponent(lblPleaseInputSsn, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addContainerGap(46, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);

	}

	private void userDeleteActionPerformed(ActionEvent evt) {
		String ID = idTxt.getText();
		if(StringUtil.isEmpty(ID)) {
			JOptionPane.showMessageDialog(null, "Please input ID");	
			return;
		}
		
		Connection con = null;
		userUpdate.setID(ID);
		
		try{
			con = dbUtil.getCon();
			int deleteinfo = userDao.deleteUser(con, userUpdate);
			if(deleteinfo == 1) {
				JOptionPane.showMessageDialog(null, "Success to delete");	
				return;
			}else {
				JOptionPane.showMessageDialog(null, "Failure to delete");	
				return;
			}	
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Failure to connect to database when deleting user!");
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		
	}
}
