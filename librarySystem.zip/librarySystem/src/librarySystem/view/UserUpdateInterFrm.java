package librarySystem.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;

import librarySystem.dao.UserDao;
import librarySystem.model.UserUpdate;
import librarySystem.util.DbUtil;
import librarySystem.util.StringUtil;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;

public class UserUpdateInterFrm extends JInternalFrame {
	private JTextField idTxt;
	private JTextField emailTxt;
	private JTextField addressTxt;
	private JTextField phoneTxt;
	
	private DbUtil dbUtil = new DbUtil();
	private UserDao userDao = new UserDao();
	private 	UserUpdate userUpdate = new UserUpdate();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserUpdateInterFrm frame = new UserUpdateInterFrm();
					frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserUpdateInterFrm() {
		setClosable(true);
		setTitle("UPDATE");
		setBounds(60, 45, 424, 386);
		
		JLabel lblSsn = new JLabel("ID");
		lblSsn.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		idTxt = new JTextField();
		idTxt.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Email");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		emailTxt = new JTextField();
		emailTxt.setColumns(10);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		addressTxt = new JTextField();
		addressTxt.setColumns(10);
		
		JLabel lblPhone = new JLabel("Phone");
		lblPhone.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		phoneTxt = new JTextField();
		phoneTxt.setColumns(10);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateUserinfoActionPerformed(e);
			}
		});
		btnUpdate.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updateResetUserinfoActionPerformed(e);
			}
		});
		btnReset.setFont(new Font("Times New Roman", Font.BOLD, 15));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(54)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblPhone)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblSsn)
								.addComponent(lblNewLabel)
								.addComponent(lblAddress)
								.addComponent(btnUpdate, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
									.addComponent(phoneTxt, 163, 163, 163)
									.addComponent(emailTxt, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE)
									.addComponent(btnReset)
									.addComponent(addressTxt, GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE))
								.addComponent(idTxt, GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE))))
					.addGap(83))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(29)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSsn)
						.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(49)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(emailTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAddress)
						.addComponent(addressTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPhone)
						.addComponent(phoneTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(56)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnUpdate, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnReset, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(30, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);

	}

	protected void updateUserinfoActionPerformed(ActionEvent evt) {
		String id = idTxt.getText();
		String email = emailTxt.getText();
		String address = addressTxt.getText();
		String phone = phoneTxt.getText();
		
		if(StringUtil.isEmpty(id)) {
			JOptionPane.showMessageDialog(null, "Please input ID");
			return;
		}
		if(StringUtil.isEmpty(email)) {
			JOptionPane.showMessageDialog(null, "Please input Email");
			return;
		}
		if(StringUtil.isEmpty(address)) {
			JOptionPane.showMessageDialog(null, "Please input Address");
			return;
		}
		if(StringUtil.isEmpty(phone)) {
			JOptionPane.showMessageDialog(null, "Please input Phone");
			return;
		}
		
		userUpdate.setAddress(address);
		userUpdate.setEmail(email);
		userUpdate.setPhone(phone);
		userUpdate.setID(id);
		
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int updateuser = userDao.updateUser(con, userUpdate);
			if(updateuser == 1) {
				JOptionPane.showMessageDialog(null, "Succeed to update the user info");
				userUpdateresetValue();
			}else {
				JOptionPane.showMessageDialog(null, "Failure to update the user info");
				userUpdateresetValue();
			}
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Failure to connect to database when updating users!");
			userUpdateresetValue();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		
	}

	private void updateResetUserinfoActionPerformed(ActionEvent evt) {
		this.userUpdateresetValue();
		
	}
	private void userUpdateresetValue() {
		this.idTxt.setText("");
		this.emailTxt.setText("");
		this.addressTxt.setText("");
		this.phoneTxt.setText("");
	}
}
