package librarySystem.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import librarySystem.dao.BookDao;
import librarySystem.model.Book;
import librarySystem.model.BookSearch;
import librarySystem.model.Calculate;
import librarySystem.model.Loan;
import librarySystem.util.DbUtil;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class BookReturnInterFrm extends JInternalFrame {
	private JTextField stuidTxt;
	
	private DbUtil dbUtil = new DbUtil();
	private Loan   loanbook = new Loan();
	private Loan loanSearch = new Loan();
	
	private BookDao bookDao = new BookDao();
	private Book book = new Book();
	private Calculate calcultateDiff = new Calculate();
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	Calendar cal = Calendar.getInstance();	
	
	private JTextField totalBookTxt;
	private JTextField totalFineTxt;
	private JTable fineTable;
	private JTextField changePayTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookReturnInterFrm frame = new BookReturnInterFrm();
					frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookReturnInterFrm() {
		setClosable(true);
		setBounds(10, 10, 549, 457);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		stuidTxt = new JTextField();
		stuidTxt.setColumns(10);
		
		JButton btnNewButton = new JButton("GO");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetValue();
				bookReturnActionPerformed(e);
				bookReturnFineActionPerformed(e);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblTotalBooks = new JLabel("Books");
		lblTotalBooks.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		totalBookTxt = new JTextField();
		totalBookTxt.setColumns(10);
		
		JLabel lblTotalFines = new JLabel("Fines");
		lblTotalFines.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		totalFineTxt = new JTextField();
		totalFineTxt.setColumns(10);
		
		JButton btnMoreInfo = new JButton("More Info");
		btnMoreInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				booksMoreInfoActionPerformed(e);
			}
		});
		btnMoreInfo.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JButton btnPay = new JButton("PAY");
		btnPay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				returnPayActionPerformed(e);
			}
		});
		btnPay.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton btnReturn = new JButton("RETURN");
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				returnBookActionPerformed(e);
			}
		});
		btnReturn.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		changePayTxt = new JTextField();
		changePayTxt.setColumns(10);
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addGap(31)
							.addComponent(btnReturn)
							.addPreferredGap(ComponentPlacement.RELATED, 114, Short.MAX_VALUE)
							.addComponent(btnPay)
							.addGap(49)
							.addComponent(changePayTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(11)
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
								.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 496, GroupLayout.PREFERRED_SIZE)
								.addGroup(groupLayout.createSequentialGroup()
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addGroup(groupLayout.createSequentialGroup()
											.addComponent(lblTotalBooks)
											.addPreferredGap(ComponentPlacement.UNRELATED)
											.addComponent(totalBookTxt, GroupLayout.PREFERRED_SIZE, 62, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.RELATED)
											.addComponent(btnMoreInfo))
										.addGroup(groupLayout.createSequentialGroup()
											.addGap(112)
											.addComponent(lblNewLabel)
											.addGap(44)
											.addComponent(stuidTxt, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)))
									.addPreferredGap(ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
									.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
										.addGroup(groupLayout.createSequentialGroup()
											.addComponent(btnNewButton)
											.addGap(108))
										.addGroup(groupLayout.createSequentialGroup()
											.addComponent(lblTotalFines)
											.addGap(18)
											.addComponent(totalFineTxt, GroupLayout.PREFERRED_SIZE, 90, GroupLayout.PREFERRED_SIZE)
											.addGap(26)))))))
					.addGap(18))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(22)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(stuidTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel)
						.addComponent(btnNewButton))
					.addGap(27)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTotalBooks)
						.addComponent(totalBookTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnMoreInfo)
						.addComponent(totalFineTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblTotalFines))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 197, GroupLayout.PREFERRED_SIZE)
					.addGap(26)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnReturn)
						.addComponent(changePayTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnPay))
					.addContainerGap(46, Short.MAX_VALUE))
		);
		
		fineTable = new JTable();
		fineTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				int row = fineTable.getSelectedRow();		
				int loanID = Integer.parseInt((String)fineTable.getValueAt(row, 0));
				loanSearch.setLoanId(loanID);
			}
		});
		
		
		fineTable.setModel((TableModel) new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"LoanId","Title", "DueDay","Fine"
				}
			) {
				boolean[] columnEditables = new boolean[] {
					false, false, false,false,false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
			});
		fineTable.getColumnModel().getColumn(0).setPreferredWidth(20);
		fineTable.getColumnModel().getColumn(1).setPreferredWidth(200);
		fineTable.getColumnModel().getColumn(2).setPreferredWidth(50);
		fineTable.getColumnModel().getColumn(3).setPreferredWidth(35);
		scrollPane.setViewportView(fineTable);
		getContentPane().setLayout(groupLayout);

	}

	private void returnBookActionPerformed(ActionEvent evt) {
		
		int row = fineTable.getSelectedRow();		
		int loanID = Integer.parseInt((String)fineTable.getValueAt(row, 0));
		loanbook.setLoanId(loanID);
	
		Date Dayin = cal.getTime();
		String dayin = sdf.format(Dayin);
		loanbook.setDateIn(dayin);
		
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int returnStatus = bookDao.returnBook(con, loanbook);
			if(returnStatus == 1) {
				ResultSet rs = bookDao.fineSearch(con, loanbook);
				while(rs.next()) {
					book.setISBN10(rs.getString("ISBN"));
					bookDao.returnUpdateBookStatus(con, book);	
	
					JOptionPane.showMessageDialog(null, "Succeed to return the book.");								
					return;																			
				}											
			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}	

	private void booksMoreInfoActionPerformed(ActionEvent evt) {
		DefaultTableModel dtm = (DefaultTableModel) fineTable.getModel();
		dtm.setRowCount(0);
		
		String ID = stuidTxt.getText();
		loanSearch.setCardId(ID);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = bookDao.bookMoreInfo(con, loanSearch);
			while (rs.next()) {
				Vector v = new Vector();
				v.add(rs.getString("loan_id"));
				v.add(rs.getString("title"));
				v.add(rs.getString("due_date"));
				v.add(rs.getString("fine"));					
				dtm.addRow(v);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	private void returnPayActionPerformed(ActionEvent evt) {
		String money = changePayTxt.getText();
		Connection con=null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = bookDao.fineSearchloanID(con, loanSearch);
			while(rs.next()) {
				String status = rs.getString("status");
				if(status.equals("available")) {
					bookDao.totalPayUpdate(con, loanSearch);
					if(money.isEmpty())
					{
						JOptionPane.showMessageDialog(null, "Succedd to pay " + rs.getString("fine") + " dollars!");
					}else
					{
						JOptionPane.showMessageDialog(null, "Succedd to pay " + money + " dollars!");
					}
					
					return;		
				}else {
					JOptionPane.showMessageDialog(null, "Please return the book first.");
					return;						
				}
			}		
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		
	}

	private void bookReturnFineActionPerformed(ActionEvent evt) {
		String ID = stuidTxt.getText();
		loanbook.setCardId(ID);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			
			ResultSet rs = bookDao.fineGroup1(con, loanbook);
			while(rs.next()) {
				totalBookTxt.setText(rs.getString(1));
			}
			
			ResultSet rs1 = bookDao.fineGroup2(con, loanbook);
			while(rs1.next()) {
				totalFineTxt.setText(rs1.getString(1));
			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {	
				e.printStackTrace();
			}
		}	
	}
	private void bookReturnActionPerformed(ActionEvent evt) {
		String ID = stuidTxt.getText();
		loanSearch.setCardId(ID);
		
		Date currentValue = cal.getTime();
		String CValue = sdf.format(currentValue);
		calcultateDiff.setCalValue2(CValue);
		
		Connection con = null;
		
		try {
			con = dbUtil.getCon();
			ResultSet rs = bookDao.fineUpdateListReferID(con, loanSearch);
			while (rs.next()) {
				String duedate = rs.getString("due_date");
				calcultateDiff.setCalValue1(duedate);
				ResultSet rs1 = bookDao.timeDiff(con, calcultateDiff);
				while(rs1.next()) {
					int diffcal = rs1.getInt(1);
					if(diffcal < 0) {
						String dayin = rs.getString("date_in");
						if(dayin == null) {
							float Bookfines = (float) (Math.abs(diffcal) * 0.25);
							loanSearch.setFine(Bookfines);
							int Finestatus = 1;
							loanSearch.setPayStatus(Finestatus);
							loanSearch.setLoanId(Integer.parseInt(rs.getString("loan_id")));
					
							bookDao.updateBookFine(con, loanSearch);
					
						}
					}
				}
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
	}

/*	private void bookReturnActionPerformed(ActionEvent evt) {
		String ID = stuidTxt.getText();
		
		Date Dayin = cal.getTime();
		String dayin = sdf.format(Dayin);
			
		loanbook.setCardId(ID);
		loanSearch.setCardId(ID);
		loanbook.setDateIn(dayin);
		
		Connection con = null;
		try {
			con = dbUtil.getCon();
			
			ResultSet rs = bookDao.duedaylist(con, loanbook);
			while(rs.next()) {
				String duedate = rs.getString("due_date");
				calcultateDiff.setCalValue1(duedate);
				calcultateDiff.setCalValue2(dayin);
				ResultSet rs1 = bookDao.timeDiff(con, calcultateDiff);
				while(rs1.next()) {
					int diffcalculate = rs1.getInt(1);				
					if(diffcalculate < 0) {
						float Bookfines = (float) (Math.abs(diffcalculate) * 0.25);
						loanSearch.setFine(Bookfines);
						int Finestatus = 1;
						loanSearch.setPayStatus(Finestatus);	
						finestatus = bookDao.updateBookFine(con, loanSearch);
					}	
					int returnStatus = bookDao.returnBook(con, loanbook);
					if(returnStatus == 1) {
						int bookStatus  = bookDao.returnUpdateBookStatus(con, book);					
						if(bookStatus == 1) {
							if(finestatus == 1) {
								JOptionPane.showMessageDialog(null, "Succeed to return the book, but You have fines to pay.");								
							}else {
								JOptionPane.showMessageDialog(null, "Succeed to return the book!");
								return;								
							}
								
						}else{
							JOptionPane.showMessageDialog(null, "Failure to return the book!");
							return;	
						}					
				}
			}
		}
	}catch (Exception e) {
		e.printStackTrace();
	} finally {
		try {
		dbUtil.closeCon(con);
	} catch (Exception e) {
		
		e.printStackTrace();
	}
	}	
		
	}
*/
	private void resetValue() {
		DefaultTableModel dtm = (DefaultTableModel) fineTable.getModel();
		dtm.setRowCount(0);
		Vector v = new Vector();
		v.add("");
		v.add("");
		v.add("");
		v.add("");
		dtm.addRow(v);
	}
}
