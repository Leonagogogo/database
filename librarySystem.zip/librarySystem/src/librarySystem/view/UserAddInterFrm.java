package librarySystem.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import librarySystem.dao.UserDao;
import librarySystem.model.Book;
import librarySystem.model.UserAdd;
import librarySystem.util.DbUtil;
import librarySystem.util.StringUtil;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class UserAddInterFrm extends JInternalFrame {
	private JTextField ssnTxt;
	private JTextField fnameTxt;
	private JTextField lnameTxt;
	private JTextField emailTxt;
	
	private DbUtil dbUtil = new DbUtil();
	private UserDao userDao = new UserDao();
	private JTextField addressTxt;
	
	private 	UserAdd userAdd=new UserAdd();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserAddInterFrm frame = new UserAddInterFrm();
					frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserAddInterFrm() {
		setClosable(true);
		setBounds(60, 45, 467, 421);
		
		JLabel lblSsn = new JLabel("SSN");
		lblSsn.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFname = new JLabel("F_name");
		lblFname.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblLname = new JLabel("L_name");
		lblLname.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		ssnTxt = new JTextField();
		ssnTxt.setColumns(10);
		
		fnameTxt = new JTextField();
		fnameTxt.setColumns(10);
		
		lnameTxt = new JTextField();
		lnameTxt.setColumns(10);
		
		emailTxt = new JTextField();
		emailTxt.setColumns(10);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					addUserActionPerformed(e);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addUserResetActionPerformed(e);
			}
		});
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		addressTxt = new JTextField();
		addressTxt.setColumns(10);
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(51)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblAddress)
							.addContainerGap())
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
							.addGroup(groupLayout.createSequentialGroup()
								.addComponent(lblEmail)
								.addContainerGap())
							.addGroup(groupLayout.createSequentialGroup()
								.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
									.addComponent(lblSsn)
									.addComponent(lblFname)
									.addComponent(lblLname))
								.addGap(24)
								.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
									.addGroup(groupLayout.createSequentialGroup()
										.addComponent(btnAdd)
										.addPreferredGap(ComponentPlacement.RELATED, 137, Short.MAX_VALUE)
										.addComponent(btnReset)
										.addGap(22))
									.addGroup(groupLayout.createSequentialGroup()
										.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
											.addComponent(ssnTxt)
											.addComponent(fnameTxt)
											.addGroup(groupLayout.createSequentialGroup()
												.addPreferredGap(ComponentPlacement.RELATED)
												.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
													.addComponent(lnameTxt, GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
													.addComponent(emailTxt)
													.addGroup(groupLayout.createSequentialGroup()
														.addGap(6)
														.addComponent(addressTxt)))))
										.addGap(77)))))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(67)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSsn)
						.addComponent(ssnTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(14)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblFname)
						.addComponent(fnameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lnameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblLname))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblEmail)
						.addComponent(emailTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAddress)
						.addComponent(addressTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAdd)
						.addComponent(btnReset))
					.addGap(20))
		);
		getContentPane().setLayout(groupLayout);

	}

	private void addUserResetActionPerformed(ActionEvent evt) {
		
		this.userresetValue();
	}
	
	private void addUserActionPerformed(ActionEvent evt) throws Exception {
		String SSNTxt = ssnTxt.getText();
		String FirstNameTxt = fnameTxt.getText();
		String LastNameTxt = lnameTxt.getText();
		String EmailTxt = emailTxt.getText();
		String AddressTxt= addressTxt.getText();
		
		Connection con=null;
		if(StringUtil.isEmpty(SSNTxt)) {
			JOptionPane.showMessageDialog(null, "Please input SSN.");
			return;
		}
		if(StringUtil.isEmpty(FirstNameTxt)) {
			JOptionPane.showMessageDialog(null, "Please input your First Name.");
			return;
		}
		if(StringUtil.isEmpty(LastNameTxt)) {
			JOptionPane.showMessageDialog(null, "Please input your Last Name.");
			return;
		}
		if(StringUtil.isEmpty(EmailTxt)) {
			JOptionPane.showMessageDialog(null, "Please input your Email.");
			return;
		}
		if(StringUtil.isEmpty(AddressTxt)) {
			JOptionPane.showMessageDialog(null, "Please input your Address.");
			return;
		}
		
		userAdd.setStuSSN(SSNTxt);
		userAdd.setStuFname(FirstNameTxt);
		userAdd.setStuLname(LastNameTxt);
		userAdd.setStuEmail(EmailTxt);
		userAdd.setStuAddress(AddressTxt);
		
		try {
			con=dbUtil.getCon();
			ResultSet rs = userDao.UserCheck(con, userAdd);
			while(rs.next()) {
				if(SSNTxt.equals(rs.getString("SSN"))) {
					JOptionPane.showMessageDialog(null, "You have already owned one library card, Cann't apply another one.");
					return;					
				}
			}
			
			int currentuser = userDao.addUser(con, userAdd);
			if (currentuser == 1) {
				ResultSet rs1 = userDao.AddUserCheck(con, userAdd);
				while(rs1.next()) {
					JOptionPane.showMessageDialog(null, "Succeed to add a new user! Your ID is  " + rs1.getString("borrower_id"));					
				}
				userresetValue();
			} else {
				JOptionPane.showMessageDialog(null, "Failure to add a new user!");
				userresetValue();
			}	
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Failure to connect to database when adding users!");
			userresetValue();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}			
		
	}
	
	private void userresetValue() {
		this.ssnTxt.setText("");
		this.fnameTxt.setText("");
		this.lnameTxt.setText("");
		this.emailTxt.setText("");
		this.addressTxt.setText("");
	}

}
