package librarySystem.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;

import librarySystem.dao.BookDao;
import librarySystem.model.Book;
import librarySystem.util.DbUtil;
import librarySystem.util.StringUtil;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;

public class BookAddInterFrm extends JInternalFrame {
	
	private DbUtil dbUtil = new DbUtil();
	private BookDao bookDao = new BookDao();
	
	private JTextField ISBN10Txt;
	private JTextField titleTxt;
	private JTextField authorTxt;
	private JTextField publisherTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookAddInterFrm frame = new BookAddInterFrm();
					frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookAddInterFrm() {
		setResizable(true);
		setClosable(true);
		setIconifiable(true);
		setRootPaneCheckingEnabled(false);
		setTitle("Add Books");
		setBounds(60, 45, 485, 395);
		
		JLabel lblNewLabel = new JLabel("ISBN10");
		
		JLabel lblNewLabel_2 = new JLabel("Title");
		
		JLabel lblNewLabel_3 = new JLabel("Author");
		
		JLabel lblNewLabel_5 = new JLabel("Publisher");
		
		ISBN10Txt = new JTextField();
		ISBN10Txt.setColumns(10);
		
		titleTxt = new JTextField();
		titleTxt.setColumns(10);
		
		authorTxt = new JTextField();
		authorTxt.setColumns(10);
		
		publisherTxt = new JTextField();
		publisherTxt.setColumns(10);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddBookActionPerformed(e);
			}
		});
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addBookResetActionPerfromed(e);
			}
		});
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(61)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(ISBN10Txt, GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_2)
								.addComponent(lblNewLabel_3))
							.addGap(24)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(titleTxt, 289, 289, 289)
								.addComponent(authorTxt, 289, 289, 289)))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel_5)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(btnNewButton)
									.addPreferredGap(ComponentPlacement.RELATED, 100, Short.MAX_VALUE)
									.addComponent(btnReset)
									.addGap(30))
								.addComponent(publisherTxt, 286, 286, 286))))
					.addGap(96))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(65)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(ISBN10Txt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(30)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_2)
						.addComponent(titleTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(19)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(authorTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_3))
					.addGap(32)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_5)
						.addComponent(publisherTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(44)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnReset))
					.addGap(53))
		);
		getContentPane().setLayout(groupLayout);

	}

	private void AddBookActionPerformed(ActionEvent evt) {
		String isbn10Txt = ISBN10Txt.getText();
		String titletxt = titleTxt.getText();
		String authortxt = authorTxt.getText();
		String publishertxt = publisherTxt.getText();
		
		if(StringUtil.isEmpty(isbn10Txt)) {
			JOptionPane.showMessageDialog(null, "ISBN10 could not be null!");
			return;
		}
		if(StringUtil.isEmpty(titletxt)) {
			JOptionPane.showMessageDialog(null, "Title could not be null!");
			return;
		}
		if(StringUtil.isEmpty(authortxt)) {
			JOptionPane.showMessageDialog(null, "Author could not be null!");
			return;
		}
		if(StringUtil.isEmpty(publishertxt)) {
			JOptionPane.showMessageDialog(null, "Publisher could not be null!");
			return;
		}
		
		Book book=new Book(isbn10Txt,titletxt,authortxt,publishertxt);
		book.setStatus("available");
		Connection con=null;
		try {
			con=dbUtil.getCon();
			int currentbook = bookDao.add(con, book);
			if (currentbook == 1) {
				JOptionPane.showMessageDialog(null, "Succeed");
				resetValue();
			} else {
				JOptionPane.showMessageDialog(null, "Failure to add a book!");
				resetValue();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Failure to connect to database when adding books!");
			resetValue();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
	}		

	
	
	private void addBookResetActionPerfromed(ActionEvent evt) {
		this.resetValue();
	}
	
	private void resetValue() {
		this.ISBN10Txt.setText("");
		this.titleTxt.setText("");
		this.authorTxt.setText("");
		this.publisherTxt.setText("");
	}
}
