package librarySystem.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import librarySystem.dao.BookDao;
import librarySystem.model.Calculate;
import librarySystem.model.Loan;
import librarySystem.util.DbUtil;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JDesktopPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

public class LibraryMainMenuFrm extends JFrame {
	
	private JDesktopPane table;
	private JPanel contentPane;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	Calendar cal = Calendar.getInstance();	
	
	private DbUtil dbUtil = new DbUtil();
	private BookDao bookDao = new BookDao();
	private Loan   loanbook = new Loan();
	private Calculate calDiff = new Calculate();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LibraryMainMenuFrm frame = new LibraryMainMenuFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LibraryMainMenuFrm() {
		setTitle("Library Manage System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 599, 533);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnBooksManage = new JMenu("Books Manage");
		menuBar.add(mnBooksManage);
		
		JMenuItem mntmSearchBooks = new JMenuItem("Search Books");
		mntmSearchBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookSearchInterFrm booksearchInterFrm = new BookSearchInterFrm();
				booksearchInterFrm.setVisible(true);
				table.add(booksearchInterFrm);
			}
		});
		mnBooksManage.add(mntmSearchBooks);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Add Books");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookAddInterFrm bookaddInterFrm = new BookAddInterFrm();
				bookaddInterFrm.setVisible(true);
				table.add(bookaddInterFrm);
			}
		});
		mnBooksManage.add(mntmNewMenuItem);
		
		JMenuItem mntmUpdateBooks = new JMenuItem("Update Books");
		mntmUpdateBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookUpdateInterFrm bookupdateInterFrm = new BookUpdateInterFrm();
				bookupdateInterFrm.setVisible(true);
				table.add(bookupdateInterFrm);
			}
		});
		mnBooksManage.add(mntmUpdateBooks);
		
		JMenuItem mntmDeleteBooks = new JMenuItem("Delete Books");
		mntmDeleteBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookDeleteInterFrm bookdeleteInterFrm = new BookDeleteInterFrm();
				bookdeleteInterFrm.setVisible(true);
				table.add(bookdeleteInterFrm);
			}
		});
		mnBooksManage.add(mntmDeleteBooks);
		
		JMenuItem mntmReturnBooks = new JMenuItem("Return Books");
		mntmReturnBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookReturnInterFrm bookreturnInterFrm = new BookReturnInterFrm();
				bookreturnInterFrm.setVisible(true);
				table.add(bookreturnInterFrm);
			}
		});
		mnBooksManage.add(mntmReturnBooks);
		
		JMenu mnUserManage = new JMenu("User Manage");
		menuBar.add(mnUserManage);
		
		JMenuItem mntmSearchUser = new JMenuItem("Search User");
		mntmSearchUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserSearchInterFrm usersearchInterFrm = new UserSearchInterFrm();
				usersearchInterFrm.setVisible(true);
				table.add(usersearchInterFrm);
			}
		});
		mnUserManage.add(mntmSearchUser);
		
		JMenuItem mntmAddUser_1 = new JMenuItem("Add User");
		mntmAddUser_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addUserActionPerformed(e);
			}
		});
		mnUserManage.add(mntmAddUser_1);
		
		JMenuItem mntmUpdateUser = new JMenuItem("Update User");
		mntmUpdateUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserUpdateInterFrm userupdateInterFrm = new UserUpdateInterFrm();
				userupdateInterFrm.setVisible(true);
				table.add(userupdateInterFrm);
			}
			
		});
		mnUserManage.add(mntmUpdateUser);
		
		JMenuItem mntmDeleteUser = new JMenuItem("Delete User");
		mntmDeleteUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserDeleteInterFrm userdeleteInterFrm = new UserDeleteInterFrm();
				userdeleteInterFrm.setVisible(true);
				table.add(userdeleteInterFrm);
			}
		});
		mnUserManage.add(mntmDeleteUser);
		
		JMenu mnFineManage = new JMenu("Fine Manage");
		menuBar.add(mnFineManage);
		
		JMenuItem mntmCheck = new JMenuItem("Update");
		mntmCheck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookFineCheckInterFrm bookfinecheckInterFrm = new BookFineCheckInterFrm();
				bookfinecheckInterFrm.setVisible(true);
				table.add(bookfinecheckInterFrm);
			}
		});
		mnFineManage.add(mntmCheck);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		table = new JDesktopPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(table, GroupLayout.DEFAULT_SIZE, 548, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(table, GroupLayout.DEFAULT_SIZE, 404, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		
		//set the frame in the middle of the screen
		this.setLocationRelativeTo(null);
	}

	private void addUserActionPerformed(ActionEvent e) {
		UserAddInterFrm useraddInterFrm = new UserAddInterFrm();
		useraddInterFrm.setVisible(true);
		table.add(useraddInterFrm);		
		
	}
}
