package librarySystem.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbUtil {
	
	private String dbUrl = "jdbc:mysql://localhost:3306/LibraryManage";
	private String dbUserName = "root";
	private String dbPassword = "ucas";
	private String jdbcName = "com.mysql.jdbc.Driver";

	/**
	 * connecting to a database
	 * @return
	 * @throws Exception
	 */
	public Connection getCon() throws Exception{
		Class.forName(jdbcName);
		Connection con = DriverManager.getConnection(dbUrl,dbUserName, dbPassword);
		
		return con;
	}
	
	/**
	 * close connecting to a database
	 * @param con
	 * @throws Exception
	 */
	public void closeCon(Connection con)throws Exception{
		if(con != null) {
			con.close();
		}
	}
	
	public static void main(String[] args) {
		DbUtil dbUtil = new DbUtil();
		try {
			dbUtil.getCon();
			System.out.println("Succeed to connect to a database");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Failure to connect to a database");
		}
	}

}
